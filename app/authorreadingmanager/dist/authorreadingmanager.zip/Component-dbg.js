sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("authorreadingmanager.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);